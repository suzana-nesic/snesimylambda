def handler(event, context):
    return "hello from the lambda"